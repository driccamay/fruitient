﻿namespace _3Gear.Core.Engine {

    using UnityEditor;
    using UnityEngine.UI;
    using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using System.IO;
using Library.Engine;

public class LoadingScene : LoadingSceneBase
{
    LoadingScene()
    {
    }   




        
    }
}
