﻿namespace _3Gear.Library.Engine 
{
    
    using UnityEditor;
    using UnityEngine.UI;
    using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using System.IO;


public abstract class RotateImageBase : MonoBehaviour
{
    // Start is called before the first frame update
   [SerializeField]
   private float _speed = 2;

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(new Vector3(0, 0, -45) * Time.deltaTime * _speed);
    }
    }
}
