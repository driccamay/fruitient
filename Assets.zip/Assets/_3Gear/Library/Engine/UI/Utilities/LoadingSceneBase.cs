﻿namespace _3Gear.Library.Engine 
{

    using UnityEditor;
    using UnityEngine.UI;
    using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using System.IO;

public abstract class LoadingSceneBase : MonoBehaviour
{
    
    private enum _loadingProgressType 
    { Real, Virtual }

    private enum _loadingInfoType
    { percentage, text, none }

    private AsyncOperation _asyncOperation;

    [Header("*** DRUG & DROP THE GAME OBJECT ***")] 
    [SerializeField, Tooltip("Drag and drop the screen image UI game object.")] 
    private GameObject _loadingScreenBG;

    [SerializeField, Tooltip("Drag and drop the slider UI game object.")]
    private Slider _progressBar;

    [SerializeField, Tooltip("Drag and drop the slider UI game object.")]
    private Text _loadingText;

    [Header("*** SCENE HAVE TO LOAD ***")]
    [SerializeField, Tooltip("Insert the scene name to load. \nWARNING: without scene name the load will not work.")]
    private string _sceneNameToLoad;

    [Header("*** LOADING BAR CONFIGURATION ***")]
    [SerializeField, Tooltip("Choose the progress type of the loading bar .")]
    private _loadingProgressType _progressType = new _loadingProgressType();

    [SerializeField, Tooltip("Choose the information type of the loading bar .")]
    private _loadingInfoType _infoType = new _loadingInfoType();
    
    [SerializeField, Tooltip("Activate the pause of the percentage loading progress.")]
    private bool _orderToContinue;

    [SerializeField, Tooltip("Insert the info message to continue to the new scene.")]
    private string _pauseMessage = "Press Any Key To Continue";

    [SerializeField, Range(1, 5), Tooltip("Choose duration delay in the seconds to the next scene.")]
    private float _secondsToContinue = 1;

    [Header("*** VIRTUAL LOADING PARAMETERS ***")]
    [SerializeField, Range(0,1), Tooltip("Insert the virtual increment of the loading bar progress.")]
    private float _virtualIncrement = 0.2f;
    
    [SerializeField, Range(0, 5), Tooltip("Insert the virtual increment duration timing of the loading barprogress.")]
    private float _virtualTiming = 1f;

public virtual void LoadLevel()
{
    if (_sceneNameToLoad == "" || _sceneNameToLoad == null)
{
    Debug.Log ("Missing secene name. Insert it");
    return;
}
    if (_sceneNameToLoad != "" || _sceneNameToLoad != null)
{

    if (_loadingScreenBG != null)
    _loadingScreenBG.SetActive(true);

     if (_progressBar != null)
    _progressBar.gameObject.SetActive(true);

     if (_loadingText != null)
    _loadingText.gameObject.SetActive(true);

    if (_progressType == _loadingProgressType.Real)
    {
        StartCoroutine(RealLoadingProgress());
    }
    if (_progressType == _loadingProgressType.Virtual)
    {
        StartCoroutine(VirtualLoadingProgress());

}
}

}
//methods

private IEnumerator RealLoadingProgress()
{
    yield return new WaitForSeconds (_secondsToContinue);

    _asyncOperation = SceneManager.LoadSceneAsync(_sceneNameToLoad);
    _asyncOperation.allowSceneActivation = false;

    while (!_asyncOperation.isDone)
    {
        if (_asyncOperation.progress == 0.9f)
        {
            if (_progressBar != null)
            {
            _ShowloadingProgressInfo();
        }   
        else
        {
            Debug.Log("Progress bar missing!");
        }
        if (!_orderToContinue)
        {
        yield return new WaitForSeconds (_secondsToContinue);
    }
    ActivatePauseMessage();
}
yield return null;
}
}


//Methods

private IEnumerator VirtualLoadingProgress()
{
    yield return new WaitForSeconds(_secondsToContinue);

    while (_progressBar.value != 1f)
    {
        _progressBar.value += _virtualIncrement;

        if (_progressBar != null)
        {
            _ShowloadingProgressInfo();
        }
        else
        {
            Debug.Log("Progress bar missing!");

        }
        yield return new WaitForSeconds(_virtualTiming);

    }
    while (_progressBar.value == 1f)
    {
        if (! _orderToContinue)
        {       
            yield return new WaitForSeconds(_secondsToContinue);

        }
        ActivatePauseMessage();
        yield return null;

    }
}



    private void _ShowloadingProgressInfo()
    {
        if(_progressType == _loadingProgressType.Real)
        {

            float progressFill = Mathf.Clamp01(_asyncOperation.progress / 0.9f);
            _progressBar.value = progressFill;

            switch (_infoType)
            {

                case _loadingInfoType.percentage:
                    _loadingText.text  = (progressFill * 100).ToString ("f0") + "%";
                    break;
                
                case _loadingInfoType.text:
                    _loadingText.text = "Loading...";
                    break;

                case _loadingInfoType.none:
                    _loadingText.text= "";
                    break;



                default:
                    break;
 
            }
      
        }
    

        if (_progressType == _loadingProgressType.Virtual)
        {
            switch (_infoType)
            {
                 case _loadingInfoType.percentage:
                    _loadingText.text = (_progressBar.value * 100).ToString("f0") + "%";
                    break;
            
                     case _loadingInfoType.text:
                    _loadingText.text = "Loading...";
                    break;

                    case _loadingInfoType.none:
                    _loadingText.text= "";
                    break;

                     default:
                    break;

            }

        }
   
    }



 //Method
 //pause message activation 

    private void ActivatePauseMessage()
    {
        if (_orderToContinue == true)
        {
            _loadingText.text = _pauseMessage;

            if (Input.anyKey)
            {
                switch (_progressType)
                {
                    case _loadingProgressType.Real:
                        _asyncOperation.allowSceneActivation = true;
                        break;

                    case _loadingProgressType.Virtual:

                        SceneManager.LoadScene(_sceneNameToLoad);

                        break;
                    
                    
                    default:
                        break;

                }    
            } 
        }                 
        else
        {
            switch(_progressType)
            {   
                case _loadingProgressType.Real:

                    _asyncOperation.allowSceneActivation = true;

                    break;
                
                case _loadingProgressType.Virtual:

                    SceneManager.LoadScene(_sceneNameToLoad);

                    break;

                default:
                    break;

            }    


        }
    }

        }

    }


















