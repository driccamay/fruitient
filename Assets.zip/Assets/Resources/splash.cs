﻿using System.Collections;
using UnityEngine;

public class splash : MonoBehaviour
{
    void Start() {
		StartCoroutine(Example());
	}

	IEnumerator Example() {
		yield return new WaitForSeconds(2);
		Application.LoadLevel ("loading");
	}
}
