﻿
using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class menu : MonoBehaviour {

	public void GoToMainMenu(){
		Application.LoadLevel("main_menu");
	}

	public void GoToARCamera(){
		Application.LoadLevel("ARCamera");
	}

	public void ExitApplication(){
		Application.Quit ();
	}

	public void GoToaboutus(){
		SceneManager.LoadScene("aboutus");
}
	public void GoToHealthScene(){
		SceneManager.LoadScene("bananas");
}

	public void GoToBananaPanel(){
		SceneManager.LoadScene("BananaPanel");
}
}

