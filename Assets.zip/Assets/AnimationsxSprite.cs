﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnimationsxSprite : MonoBehaviour {

    public Sprite[] animatedImages;
	public Image animateImageObj;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
	animateImageObj.sprite = animatedImages [(int)(Time.time*1)%animatedImages.Length];
// var index: int = (Time.time * framesPerSecond) % frames.Length;
// renderer.material.mainTexture = frames[index];        
    }
}
